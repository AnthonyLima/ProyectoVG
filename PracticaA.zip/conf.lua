function love.conf(t)
	t.title = "Ejemplo usando Love"
	t.version = '0.9.1'
	t.window.width = 640
	t.window.height = 480
end